#ifndef __S_H
#define __SL_H

#include <stdio.h>

void S_Init(void);
void S_SendByte(uint8_t Byte);
void S_SendArray(uint8_t *Array, uint16_t Length);
void S_SendString(char *String);
void S_SendNumber(uint32_t Number, uint8_t Length);
void S_Printf(char *format, ...);

#endif

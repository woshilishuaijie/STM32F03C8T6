#include "Device/Include/stm32f10x.h"   // Device header
#include "Delay.h"

void key_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_11;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
}

uint8_t key_GetNum(void)//key����
{
	uint8_t key_GetNum=0;       //�ֲ��м����
	if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==0)     //��ȡB1�ĵ�ƽ
	{
		Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==0)
		Delay_ms(20);
		key_GetNum=1;  
	}
	
	if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)==0)    //��ȡB11�ĵ�ƽ
	{
		Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)==0)
		Delay_ms(20);
		key_GetNum=2;   
	}
	return key_GetNum;   
}

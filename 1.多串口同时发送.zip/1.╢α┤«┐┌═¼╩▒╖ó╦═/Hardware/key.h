#ifndef __KEY_H
#define __KEY_H

void key_Init(void);
uint8_t key_GetNum(void);

#endif
